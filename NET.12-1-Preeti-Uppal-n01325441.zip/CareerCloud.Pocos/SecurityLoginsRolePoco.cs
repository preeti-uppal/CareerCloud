﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CareerCloud.Pocos
{[Table("Security_Logins_Roles")]
    class SecurityLoginsRolePoco:IPoco
    {
        [Key]
        public Guid Id { get; set; }

        public Guid Login { get; set; }

        public Guid Role { get; set; }
        [Column("Time_Stamp")]
        public byte[] TimeStamp { get; set; }
    }
}
